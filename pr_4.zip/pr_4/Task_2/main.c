#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

int main(int argc, char **argv) {
    srand(time(NULL));
    char *opts = "ho:с"; 
    int a, b; 
    char op; 
    int opt; 
        while((opt = getopt(argc, argv, opts)) != -1) {
            switch(opt) {
                case 'h':{ 
                    printf("-h - help\n");
                    printf("-o - new file with unique name\n");
                    printf("-c - spectil mode\n");
                break;}
                case 'o':{ 
                   
                    int i;
                    char *str = optarg;
                    char *str1;
                    strcpy(str1, "touch ");
                    strcat(str1, str);
                    strcat(str1,".txt");
                    printf("%s\n",str1);
                    system(str1);
                break;}
                case 'с':{
                    printf("Special mode activated!!!\n");
                break;}
            }
        }      
 return 0;
}
