#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

void quadratic_equation(int a, int b, int c){
    double D = (b * b) - (4 * a * c);
    if (D < 0) printf("(%d)x^2 + (%d)x + (%d) = 0 \nDon't have any solution!\n",a,b,c);
    if (D == 0) printf("(%d)x^2 + (%d)x + (%d) = 0 \nOnly one solution! X = %.3f\n",a,b,c, (double)((double)-b / (2 * a)));
    if (D > 0) printf("(%d)x^2 + (%d)x + (%d) = 0 \nTwo solutions! X1 = %f X2 = %.3f\n",a,b,c, (double)((-b + (sqrt(D)))/(2 * a)),(double)((-b - (sqrt(D)))/(2 * a)));
}

int main(int argc, char **argv) { 
 
    quadratic_equation(atoi(argv[1]), atoi(argv[2]), atoi(argv[3]));
     
}


