#!/bin/sh

X=1
Y=5
RANGE=$((Y-X+1))
RANDOM=$$
R=$(($(($RANDOM%$RANGE))+X))
R1=$(($(($RANDOM%($RANGE+10)))+R))
R2=$(($(($RANDOM%($RANGE)))+R))
./main $R $R1 $R2
